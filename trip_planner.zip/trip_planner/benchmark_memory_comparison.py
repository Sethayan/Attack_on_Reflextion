"""
Benchmark: Memory vs No-Memory Comparison

Runs 5 fixed trip-planning test cases under two conditions:
  1. no_memory  — reflexion memory disabled (no retrieve / no store)
  2. with_memory — reflexion memory enabled (retrieve past lessons + store new)

Each output is scored by the evaluator (heuristic + LLM judge).
Results are saved to benchmark_memory_comparison.csv with a printed summary.

Usage:
    python3 benchmark_memory_comparison.py
"""

import csv
import os
import sys
import time
from collections import defaultdict
from textwrap import dedent

from crewai import Crew
from dotenv import load_dotenv

from evaluator import evaluate
from reflexion_memory import ReflexionMemory
from trip_agents import TripAgents
from trip_tasks import TripTasks

load_dotenv()

# ──────────────────────────────────────────────────────────────────────
#  Test cases
# ──────────────────────────────────────────────────────────────────────

TEST_CASES = [
    {
        "id": 1,
        "origin": "Mumbai",
        "cities": "Paris, Rome, Barcelona",
        "date_range": "June 1-7, 2026",
        "interests": "art, food, history",
    },
    {
        "id": 2,
        "origin": "London",
        "cities": "Lisbon, Athens, Istanbul",
        "date_range": "September 1-5, 2026",
        "interests": "beaches, nightlife",
    },
]


# ──────────────────────────────────────────────────────────────────────
#  Crew runner (with / without memory)
# ──────────────────────────────────────────────────────────────────────

def run_crew(test_case: dict, use_memory: bool) -> str:
    """Run the trip planner crew for a single test case.

    Args:
        test_case: dict with origin, cities, date_range, interests.
        use_memory: if True, use reflexion memory; if False, skip it.

    Returns:
        The crew output as a string.
    """
    agents = TripAgents()
    tasks = TripTasks()

    city_selector_agent = agents.city_selection_agent()
    local_expert_agent = agents.local_expert()
    travel_concierge_agent = agents.travel_concierge()

    reflexion_context = ""
    memory = None
    task_description = (
        f"Plan a trip from {test_case['origin']} to one of "
        f"{test_case['cities']} during {test_case['date_range']}, "
        f"interests: {test_case['interests']}"
    )

    if use_memory:
        memory = ReflexionMemory()
        past_reflections = memory.retrieve_relevant(task_description)
        if past_reflections:
            lessons = "\n---\n".join(past_reflections)
            reflexion_context = dedent(f"""\

                === LESSONS FROM PREVIOUS RUNS ===
                The following reflections were generated from prior trip-planning
                runs. Use them to avoid past mistakes and improve your output:

                {lessons}

                === END OF LESSONS ===

            """)

    identify_task = tasks.identify_task(
        city_selector_agent,
        test_case["origin"],
        test_case["cities"],
        test_case["interests"],
        test_case["date_range"],
        extra_context=reflexion_context,
    )
    gather_task = tasks.gather_task(
        local_expert_agent,
        test_case["origin"],
        test_case["interests"],
        test_case["date_range"],
    )
    plan_task = tasks.plan_task(
        travel_concierge_agent,
        test_case["origin"],
        test_case["interests"],
        test_case["date_range"],
    )

    crew = Crew(
        agents=[city_selector_agent, local_expert_agent, travel_concierge_agent],
        tasks=[identify_task, gather_task, plan_task],
        verbose=True,
    )

    result = crew.kickoff()

    # Store reflection for future runs (only in memory condition)
    if use_memory and memory is not None:
        memory.reflect_and_store(task_description, str(result))

    return str(result)


# ──────────────────────────────────────────────────────────────────────
#  Main benchmark
# ──────────────────────────────────────────────────────────────────────

CSV_FILE = "benchmark_memory_comparison.csv"

CHECK_KEYS = [
    "budget_ok", "days_ok", "no_duplicates",
    "constraints_ok", "feasible", "no_hallucination",
]

CSV_COLUMNS = [
    "test_case", "condition", "overall_pass",
    *CHECK_KEYS,
    "failure_reasons", "execution_time_s",
]


def run_benchmark():
    """Run all test cases under both conditions and save results."""
    all_results = []
    total_runs = len(TEST_CASES) * 2
    run_count = 0

    for condition in ["no_memory", "with_memory"]:
        use_memory = condition == "with_memory"
        print(f"\n{'='*70}")
        print(f"  CONDITION: {condition.upper()}")
        print(f"{'='*70}\n")

        for tc in TEST_CASES:
            run_count += 1
            print(f"\n--- Run {run_count}/{total_runs}: "
                  f"Test #{tc['id']} ({condition}) ---")
            print(f"    {tc['origin']} → {tc['cities']} | "
                  f"{tc['date_range']} | {tc['interests']}")

            start = time.time()
            try:
                output_text = run_crew(tc, use_memory=use_memory)
            except Exception as e:
                print(f"    ❌ Crew run FAILED: {e}")
                output_text = f"[ERROR] Crew run failed: {e}"
            elapsed = time.time() - start

            print(f"    ⏱  {elapsed:.1f}s elapsed")
            print(f"    📝 Output length: {len(output_text)} chars")

            # Build task_input dict for evaluator
            task_input = {
                "origin": tc["origin"],
                "cities": tc["cities"],
                "date_range": tc["date_range"],
                "interests": tc["interests"],
            }

            print("    🔍 Running evaluator...")
            eval_result = evaluate(task_input, output_text)

            row = {
                "test_case": tc["id"],
                "condition": condition,
                "overall_pass": eval_result["overall_pass"],
                "execution_time_s": round(elapsed, 1),
                "failure_reasons": "; ".join(eval_result["failure_reasons"]),
            }
            for ck in CHECK_KEYS:
                row[ck] = eval_result.get(ck)

            all_results.append(row)

            status = "✅ PASS" if eval_result["overall_pass"] else "❌ FAIL"
            print(f"    {status}")
            if eval_result["failure_reasons"]:
                for fr in eval_result["failure_reasons"]:
                    print(f"       → {fr}")

    # ── Save CSV ─────────────────────────────────────────────────────
    with open(CSV_FILE, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for r in all_results:
            writer.writerow(r)
    print(f"\n📄 Results saved to {CSV_FILE}")

    # ── Print summary ────────────────────────────────────────────────
    print_summary(all_results)


def print_summary(results: list):
    """Print comparison summary table."""
    print(f"\n{'='*70}")
    print("  BENCHMARK SUMMARY")
    print(f"{'='*70}\n")

    for condition in ["no_memory", "with_memory"]:
        cond_results = [r for r in results if r["condition"] == condition]
        n = len(cond_results)
        passes = sum(1 for r in cond_results if r["overall_pass"])
        pass_rate = (passes / n * 100) if n else 0

        print(f"  {condition.upper():>12}: {passes}/{n} passed ({pass_rate:.0f}%)")

    print()

    # Failure frequency breakdown
    print("  FAILURE FREQUENCY BY CHECK:")
    print(f"  {'Check':<20} | {'no_memory':>10} | {'with_memory':>12}")
    print(f"  {'-'*20}-+-{'-'*10}-+-{'-'*12}")

    for ck in CHECK_KEYS:
        counts = {}
        for condition in ["no_memory", "with_memory"]:
            cond_results = [r for r in results if r["condition"] == condition]
            fail_count = sum(1 for r in cond_results if r.get(ck) is False)
            counts[condition] = fail_count
        print(f"  {ck:<20} | {counts['no_memory']:>10} | {counts['with_memory']:>12}")

    # Execution time comparison
    print()
    for condition in ["no_memory", "with_memory"]:
        cond_results = [r for r in results if r["condition"] == condition]
        times = [r["execution_time_s"] for r in cond_results]
        avg_time = sum(times) / len(times) if times else 0
        print(f"  {condition.upper():>12} avg time: {avg_time:.1f}s")

    print()


if __name__ == "__main__":
    print("╔══════════════════════════════════════════════════════════════════╗")
    print("║  BENCHMARK: Memory vs No-Memory Comparison                     ║")
    print("║  2 test cases × 2 conditions = 4 crew runs                     ║")
    print("╚══════════════════════════════════════════════════════════════════╝")
    print()

    run_benchmark()
