"""
Reflexion Memory — a RAG-based self-critique system for multi-agent runs.

Implements the Reflexion pattern (Shinn et al., 2023): after each crew run the
local LLM generates verbal self-feedback ("what worked, what didn't, what to
improve"), which is stored in a ChromaDB vector collection.  Before the next
run, relevant past reflections are retrieved via similarity search and injected
as extra context so agents can learn from prior mistakes.

All embeddings and LLM calls use local Ollama models — no cloud dependency.
"""

import uuid
from datetime import datetime, timezone
from typing import List, Optional

import chromadb
from chromadb.utils import embedding_functions
from crewai import LLM


class ReflexionMemory:
    """ChromaDB-backed reflexion memory with local Ollama embeddings."""

    def __init__(
        self,
        persist_dir: str = "./chroma_reflexion_db",
        ollama_url: str = "http://localhost:11434",
        embedding_model: str = "nomic-embed-text",
        llm_model: str = "ollama/qwen2.5:7b",
        collection_name: str = "reflexion_logs",
    ):
        # ── Embedding function (Ollama) ─────────────────────────────
        self._embedding_fn = embedding_functions.OllamaEmbeddingFunction(
            url=ollama_url,
            model_name=embedding_model,
        )

        # ── ChromaDB persistent client ──────────────────────────────
        self._client = chromadb.PersistentClient(path=persist_dir)
        self._collection = self._client.get_or_create_collection(
            name=collection_name,
            embedding_function=self._embedding_fn,
        )

        # ── Local LLM for self-critique ─────────────────────────────
        self._llm = LLM(model=llm_model, base_url=ollama_url)

    # ------------------------------------------------------------------ #
    #  Core API                                                            #
    # ------------------------------------------------------------------ #

    def reflect(self, task_description: str, output: str) -> str:
        """Ask the local LLM to critique the completed task output.

        Returns a free-text reflection covering what worked, what didn't,
        and actionable improvements for future runs.
        """
        prompt = (
            "You are an expert AI reviewer.  A multi-agent trip-planning "
            "system just completed the task described below and produced "
            "the output shown.  Provide a concise, actionable reflection "
            "covering:\n"
            "1. What went well\n"
            "2. What went poorly or was missing\n"
            "3. Specific improvements for next time\n\n"
            f"=== TASK ===\n{task_description}\n\n"
            f"=== OUTPUT ===\n{output[:6000]}\n\n"
            "=== YOUR REFLECTION ==="
        )
        return self._llm.call(prompt)

    def store(
        self,
        task_description: str,
        output: str,
        reflection: str,
    ) -> str:
        """Persist a reflection in ChromaDB.

        Returns the generated document ID.
        """
        doc_id = str(uuid.uuid4())
        # The *document* stored (and embedded) is the reflection itself so
        # that similarity search matches on the critique's semantic content.
        self._collection.add(
            documents=[reflection],
            ids=[doc_id],
            metadatas=[
                {
                    "task_description": task_description[:1000],
                    "output_preview": output[:500],
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            ],
        )
        return doc_id

    def retrieve_relevant(
        self,
        current_task_description: str,
        n_results: int = 2,
    ) -> List[str]:
        """Return the most relevant past reflections for a new task.

        Uses ChromaDB similarity search against stored reflection
        documents.  Returns an empty list when the collection is empty.
        """
        if self._collection.count() == 0:
            return []

        results = self._collection.query(
            query_texts=[current_task_description],
            n_results=min(n_results, self._collection.count()),
        )
        # results["documents"] is a list-of-lists; flatten the outer one
        return results["documents"][0] if results["documents"] else []

    def reflect_and_store(
        self,
        task_description: str,
        output: str,
    ) -> str:
        """Convenience: generate a reflection and store it in one call.

        Returns the stored document ID.
        """
        reflection = self.reflect(task_description, output)
        doc_id = self.store(task_description, output, reflection)
        return doc_id
