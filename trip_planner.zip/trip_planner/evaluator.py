"""
Evaluator — heuristic checks + LLM judge for trip-planner output quality.

Part A: Deterministic Python checks (budget, day count, duplicate activities).
Part B: LLM judge via llama3.1:8b (constraints, feasibility, hallucination).

The judge model is intentionally different from the agent model (qwen2.5:7b)
to avoid self-grading bias.
"""

import json
import re
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

from crewai import LLM


# ──────────────────────────────────────────────────────────────────────
#  Part A — Heuristic Checker (deterministic, zero LLM calls)
# ──────────────────────────────────────────────────────────────────────

def _extract_budget_from_input(task_input: dict) -> Optional[float]:
    """Try to find a numeric budget cap in the task input fields."""
    # Check for an explicit 'budget' key
    if "budget" in task_input and task_input["budget"]:
        raw = str(task_input["budget"])
        nums = re.findall(r"[\d,]+(?:\.\d+)?", raw.replace(",", ""))
        if nums:
            return float(nums[0])

    # Scan all input values for budget-like phrases
    combined = " ".join(str(v) for v in task_input.values())
    patterns = [
        r"budget\s*(?:of|is|:)?\s*\$?([\d,]+(?:\.\d+)?)",
        r"\$?([\d,]+(?:\.\d+)?)\s*budget",
        r"under\s*\$?([\d,]+(?:\.\d+)?)",
        r"max(?:imum)?\s*\$?([\d,]+(?:\.\d+)?)",
    ]
    for pat in patterns:
        m = re.search(pat, combined, re.IGNORECASE)
        if m:
            return float(m.group(1).replace(",", ""))
    return None


def _extract_totals_from_output(output_text: str) -> List[float]:
    """Extract dollar/currency amounts near 'total', 'budget', 'cost'."""
    totals = []
    # Look for lines with total/budget/cost and a currency amount
    for line in output_text.split("\n"):
        lower = line.lower()
        if any(kw in lower for kw in ["total", "budget", "overall cost", "grand total", "estimated cost"]):
            amounts = re.findall(
                r"[\$€£]?\s*([\d,]+(?:\.\d{1,2})?)\s*(?:usd|eur|gbp|dollars?|euros?)?",
                line, re.IGNORECASE,
            )
            for a in amounts:
                val = float(a.replace(",", ""))
                if val > 10:  # filter out trivially small numbers
                    totals.append(val)
    return totals


def check_budget(task_input: dict, output_text: str) -> dict:
    """Check if output budget stays within input budget cap."""
    budget_cap = _extract_budget_from_input(task_input)
    if budget_cap is None:
        return {"result": "not_applicable", "reason": "No budget specified in input."}

    totals = _extract_totals_from_output(output_text)
    if not totals:
        return {"result": "not_applicable", "reason": "No cost total found in output to compare."}

    max_total = max(totals)
    if max_total > budget_cap:
        return {
            "result": False,
            "reason": f"Output total ${max_total:.0f} exceeds budget cap ${budget_cap:.0f}.",
        }
    return {"result": True, "reason": ""}


def _parse_trip_length(task_input: dict) -> Optional[int]:
    """Infer expected number of days from the date range string."""
    date_range = str(task_input.get("date_range", ""))

    # Pattern: "June 1-7" or "June 1 - 7" (same month)
    m = re.search(r"(\d{1,2})\s*[-–]\s*(\d{1,2})", date_range)
    if m:
        start, end = int(m.group(1)), int(m.group(2))
        if end > start:
            return end - start + 1

    # Pattern: explicit "X days" or "X-day"
    m = re.search(r"(\d+)\s*[-]?\s*days?", date_range, re.IGNORECASE)
    if m:
        return int(m.group(1))

    return None


def _count_days_in_output(output_text: str) -> int:
    """Count distinct day numbers mentioned in output."""
    # Match "Day 1", "Day 2", etc.
    day_nums = set()
    for m in re.finditer(r"\bday\s*(\d+)\b", output_text, re.IGNORECASE):
        day_nums.add(int(m.group(1)))

    # Also match date-style headers like "June 1:", "June 2:", etc.
    for m in re.finditer(r"\b(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", output_text, re.IGNORECASE):
        day_nums.add(len(day_nums) + 1)  # approximate

    return len(day_nums) if day_nums else 0


def check_days(task_input: dict, output_text: str) -> dict:
    """Check if number of days in output matches requested trip length."""
    expected = _parse_trip_length(task_input)
    if expected is None:
        return {"result": "not_applicable", "reason": "Could not parse trip length from input."}

    actual = _count_days_in_output(output_text)
    if actual == 0:
        return {"result": False, "reason": "No day markers (Day 1, Day 2...) found in output."}

    if actual != expected:
        return {
            "result": False,
            "reason": f"Expected {expected} days, found {actual} days in output.",
        }
    return {"result": True, "reason": ""}


def _split_into_day_sections(output_text: str) -> Dict[str, str]:
    """Split output into per-day text sections."""
    sections = {}
    # Split on "Day N" headers
    parts = re.split(r"(?i)\b(day\s*\d+)\b", output_text)
    current_day = None
    for part in parts:
        if re.match(r"(?i)day\s*\d+", part.strip()):
            current_day = part.strip().lower()
            sections[current_day] = ""
        elif current_day:
            sections[current_day] += part
    return sections


def _extract_venue_names(text: str) -> List[str]:
    """Extract plausible venue/activity names from a day section.

    Heuristic: look for capitalized multi-word phrases (likely proper nouns)
    that are at least 2 words and appear in contexts suggesting venues.
    """
    venues = []
    # Match sequences of capitalized words (2+ words, likely venue names)
    for m in re.finditer(r"(?:visit|go to|explore|dine at|eat at|see|tour|check out)?\s*([A-Z][a-zA-Zéèêëàâäùûüôöîïç'-]+(?:\s+[A-Z][a-zA-Zéèêëàâäùûüôöîïç'-]+)+)", text):
        name = m.group(1).strip()
        if len(name) > 4:  # skip very short matches
            venues.append(name.lower())

    # Also capture **bold** items (markdown) which often denote venues
    for m in re.finditer(r"\*\*([^*]+)\*\*", text):
        name = m.group(1).strip()
        if len(name) > 4 and not name.lower().startswith(("day", "morning", "afternoon", "evening", "night", "budget", "total")):
            venues.append(name.lower())

    return venues


def check_no_duplicates(task_input: dict, output_text: str) -> dict:
    """Check for repeated activities/venues across different days."""
    sections = _split_into_day_sections(output_text)
    if len(sections) < 2:
        return {"result": "not_applicable", "reason": "Could not split output into day sections."}

    # Build venue → days mapping
    venue_days = defaultdict(set)
    for day_label, text in sections.items():
        for venue in _extract_venue_names(text):
            venue_days[venue].add(day_label)

    # Find duplicates (same venue in 2+ days)
    duplicates = {v: list(days) for v, days in venue_days.items() if len(days) >= 2}

    if duplicates:
        dup_list = "; ".join(f"'{v}' in {d}" for v, d in list(duplicates.items())[:3])
        return {
            "result": False,
            "reason": f"Duplicate venues across days: {dup_list}",
        }
    return {"result": True, "reason": ""}


def run_heuristic_checks(task_input: dict, output_text: str) -> dict:
    """Run all heuristic checks. Returns dict of check_name → result."""
    budget = check_budget(task_input, output_text)
    days = check_days(task_input, output_text)
    dupes = check_no_duplicates(task_input, output_text)
    return {
        "budget_ok": budget["result"],
        "budget_reason": budget["reason"],
        "days_ok": days["result"],
        "days_reason": days["reason"],
        "no_duplicates": dupes["result"],
        "no_duplicates_reason": dupes["reason"],
    }


# ──────────────────────────────────────────────────────────────────────
#  Part B — LLM Judge (llama3.1:8b via Ollama)
# ──────────────────────────────────────────────────────────────────────

# Judge LLM — intentionally different from agent model to avoid self-grading
_judge_llm = LLM(
    model="ollama/llama3.1:8b",
    base_url="http://localhost:11434",
    temperature=0.1,
)


def _parse_judge_json(raw: str) -> Optional[dict]:
    """Parse JSON from judge response, handling markdown fences gracefully."""
    # Strip markdown code fences if present
    cleaned = raw.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    cleaned = cleaned.strip()

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        # Try to find JSON object within the response
        m = re.search(r"\{[^{}]*\}", cleaned, re.DOTALL)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass
        return None


def run_llm_judge(task_input: dict, output_text: str) -> dict:
    """Run the LLM judge on the output. Returns dict of check results."""
    input_summary = (
        f"Origin: {task_input.get('origin', 'N/A')}\n"
        f"Cities: {task_input.get('cities', 'N/A')}\n"
        f"Date Range: {task_input.get('date_range', 'N/A')}\n"
        f"Interests: {task_input.get('interests', 'N/A')}\n"
    )
    if task_input.get("constraints"):
        input_summary += f"Constraints: {task_input['constraints']}\n"

    # Truncate output to fit context window
    truncated_output = output_text[:6000]

    prompt = (
        "You are a strict travel-plan evaluator. Given the TASK INPUT and "
        "the PLAN OUTPUT below, evaluate three criteria. "
        "Respond ONLY with valid JSON, no other text, no markdown fences.\n\n"
        "Criteria:\n"
        "1. constraints_ok (bool): Were all stated constraints honored? "
        "(dietary needs, mobility needs, must-see places, correct date range, "
        "correct origin city). If no special constraints were stated, check "
        "the plan matches the requested cities, dates, and interests.\n"
        "2. feasible (bool): Is the day-to-day plan realistic? No impossible "
        "same-day cross-country travel, no 20-hour sightseeing days, "
        "reasonable timing between activities.\n"
        "3. no_hallucination (bool): Do the named venues, restaurants, and "
        "hotels sound real and plausible for the stated city? Not obviously "
        "fabricated or nonsensical names.\n\n"
        "Return JSON:\n"
        '{"constraints_ok": true/false, "feasible": true/false, '
        '"no_hallucination": true/false, "notes": "brief explanation for '
        'any false verdict"}\n\n'
        f"=== TASK INPUT ===\n{input_summary}\n"
        f"=== PLAN OUTPUT ===\n{truncated_output}\n\n"
        "Your JSON verdict:"
    )

    try:
        raw_response = _judge_llm.call(prompt)
    except Exception as e:
        print(f"[evaluator] LLM judge call failed: {e}")
        return {
            "constraints_ok": None,
            "feasible": None,
            "no_hallucination": None,
            "judge_notes": f"LLM call failed: {e}",
            "judge_raw": "",
        }

    parsed = _parse_judge_json(raw_response)

    if parsed is None:
        print(f"[evaluator] WARNING: Could not parse judge JSON. Raw response:\n{raw_response[:500]}")
        return {
            "constraints_ok": None,
            "feasible": None,
            "no_hallucination": None,
            "judge_notes": "JSON parse failure",
            "judge_raw": raw_response[:500],
        }

    return {
        "constraints_ok": parsed.get("constraints_ok"),
        "feasible": parsed.get("feasible"),
        "no_hallucination": parsed.get("no_hallucination"),
        "judge_notes": parsed.get("notes", ""),
        "judge_raw": "",
    }


# ──────────────────────────────────────────────────────────────────────
#  Combined Evaluator
# ──────────────────────────────────────────────────────────────────────

def evaluate(task_input: dict, output_text: str) -> dict:
    """Run all checks and return a combined verdict.

    Args:
        task_input: dict with keys like 'origin', 'cities', 'date_range',
                    'interests', and optionally 'budget', 'constraints'.
        output_text: the full text output from the crew run.

    Returns:
        dict with overall_pass, failure_reasons, and all individual checks.
    """
    heuristic_results = run_heuristic_checks(task_input, output_text)
    judge_results = run_llm_judge(task_input, output_text)

    # Merge all check results (exclude reason/notes/raw fields for pass logic)
    check_keys = ["budget_ok", "days_ok", "no_duplicates",
                   "constraints_ok", "feasible", "no_hallucination"]

    all_checks = {**heuristic_results, **judge_results}

    failure_reasons = []
    for k in check_keys:
        val = all_checks.get(k)
        if val is False:
            reason = all_checks.get(f"{k}_reason", "")
            failure_reasons.append(f"{k}: {reason}" if reason else k)

    overall_pass = len(failure_reasons) == 0

    return {
        "overall_pass": overall_pass,
        "failure_reasons": failure_reasons,
        **all_checks,
    }
